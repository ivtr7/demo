import { NicheConfig } from '@/data/niches';
import { supabase } from '@/integrations/supabase/client';

interface GeminiMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}

interface GeminiConfig {
  apiKey: string;
  model: string;
  temperature: number;
  topP: number;
  maxOutputTokens: number;
}

interface ChatContext {
  userName: string;
  businessName: string;
  extraValue: string;
  niche: NicheConfig;
}

// Call Gemini API directly (when user has API key)
async function callGemini(
  messages: GeminiMessage[],
  systemPrompt: string,
  config: GeminiConfig
): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${config.model}:generateContent?key=${config.apiKey}`;
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: messages,
      systemInstruction: {
        parts: [{ text: systemPrompt }],
      },
      generationConfig: {
        temperature: config.temperature,
        topP: config.topP,
        maxOutputTokens: config.maxOutputTokens,
      },
    }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.error?.message || 'Erro ao chamar Gemini API');
  }

  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || 'Desculpe, não consegui processar sua mensagem.';
}

// Call Lovable AI via Edge Function (fallback)
async function callLovableAI(
  messages: { role: 'user' | 'assistant'; content: string }[],
  context: ChatContext
): Promise<string> {
  const { data, error } = await supabase.functions.invoke('chat', {
    body: {
      messages: messages.map(m => ({
        role: m.role,
        content: m.content
      })),
      systemPrompt: context.niche.systemPrompt,
      nicheContext: {
        agentName: context.niche.agentName,
        nicheName: context.niche.name,
        userName: context.userName,
        businessName: context.businessName,
        extraValue: context.extraValue,
        extraFieldName: context.niche.onboarding.extraFieldName,
        restrictions: context.niche.restrictions,
        rules: context.niche.rules,
      }
    }
  });

  if (error) {
    console.error('Lovable AI error:', error);
    throw new Error(error.message || 'Erro ao chamar Lovable AI');
  }

  if (data?.error) {
    throw new Error(data.error);
  }

  return data?.response || 'Desculpe, não consegui processar sua mensagem.';
}

// Test Gemini connection
export async function testGeminiConnection(apiKey: string): Promise<{ success: boolean; message: string }> {
  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: 'Diga apenas "OK" para testar a conexão.' }] }],
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      return { success: false, message: error.error?.message || 'Erro de conexão' };
    }

    return { success: true, message: 'Conexão estabelecida com sucesso!' };
  } catch (error) {
    return { success: false, message: 'Erro de rede. Verifique sua conexão.' };
  }
}

// Fill template with context variables
export function fillTemplate(template: string, context: ChatContext): string {
  return template
    .replace(/{USER_NAME}/g, context.userName || 'você')
    .replace(/{BUSINESS_NAME}/g, context.businessName || 'nossa empresa')
    .replace(/{EXTRA_VALUE}/g, context.extraValue || '')
    .replace(/{AGENT_NAME}/g, context.niche.agentName)
    .replace(/{NICHO}/g, context.niche.name)
    .replace(/{BUSINESS_LABEL}/g, context.niche.onboarding.businessLabel);
}

// Build system prompt with context
function buildSystemPrompt(niche: NicheConfig, context: Omit<ChatContext, 'niche'>): string {
  const { userName, businessName, extraValue } = context;
  
  let prompt = niche.systemPrompt + '\n\n';
  
  prompt += '=== CONTEXTO DO ATENDIMENTO ===\n';
  if (userName) prompt += `- Nome do cliente: ${userName}\n`;
  if (businessName) prompt += `- Nome do negócio: ${businessName}\n`;
  if (extraValue) prompt += `- ${niche.onboarding.extraFieldName}: ${extraValue}\n`;
  prompt += '\n';
  
  prompt += '=== REGRAS DE COMPORTAMENTO ===\n';
  if (niche.rules.useVariables) {
    prompt += '- SEMPRE use o nome do cliente e do negócio nas respostas quando fizer sentido.\n';
  }
  if (niche.rules.oneQuestionAtTime) {
    prompt += '- Faça apenas UMA pergunta por vez.\n';
  }
  if (niche.rules.suggestNextSteps) {
    prompt += '- Sempre sugira o próximo passo (agendar, conhecer, tirar dúvida).\n';
  }
  if (niche.rules.keepResponsesShort) {
    prompt += '- Mantenha as respostas curtas e objetivas (máximo 3-4 frases).\n';
  }
  
  if (niche.restrictions) {
    prompt += `\n=== RESTRIÇÕES ===\n${niche.restrictions}\n`;
  }
  
  prompt += '\n=== INSTRUÇÕES ESPECIAIS ===\n';
  prompt += '- Quando anotar algo importante, inclua: "✅ Anotado (demo): [resumo]"\n';
  prompt += '- Este é um ambiente de demonstração. Simule agendamentos e anotações.\n';
  prompt += '- Seja sempre empático e profissional.\n';
  prompt += '- Responda em português brasileiro.\n';
  
  return prompt;
}

// Main function to generate agent reply with fallback
export async function generateAgentReply(
  userMessage: string,
  chatHistory: { role: 'user' | 'assistant'; content: string }[],
  context: ChatContext,
  config: {
    apiKey: string;
    model: string;
    temperature: number;
    topP: number;
    maxOutputTokens: number;
  }
): Promise<{ response: string; source: 'gemini' | 'lovable-ai' | 'error' }> {
  
  // Prepare messages for AI
  const fullHistory = [...chatHistory, { role: 'user' as const, content: userMessage }];
  
  // Try Gemini first if API key is available
  if (config.apiKey) {
    try {
      const geminiMessages: GeminiMessage[] = fullHistory.map(msg => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }],
      }));
      
      const systemPrompt = buildSystemPrompt(context.niche, context);
      const response = await callGemini(geminiMessages, systemPrompt, config);
      
      return { response, source: 'gemini' };
    } catch (error) {
      console.warn('Gemini API error, falling back to Lovable AI:', error);
    }
  }
  
  // Fallback to Lovable AI
  try {
    const response = await callLovableAI(fullHistory, context);
    return { response, source: 'lovable-ai' };
  } catch (error) {
    console.error('Lovable AI also failed:', error);
    return { 
      response: "Desculpe, estou com dificuldades técnicas no momento. Por favor, tente novamente em alguns instantes.", 
      source: 'error' 
    };
  }
}
