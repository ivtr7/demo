import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useApp } from '@/contexts/AppContext';
import { testGeminiConnection } from '@/services/gemini';
import { useState } from 'react';
import { Eye, EyeOff, Check, X, AlertTriangle, Loader2 } from 'lucide-react';

interface SettingsDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function SettingsDrawer({ open, onOpenChange }: SettingsDrawerProps) {
  const {
    theme,
    setTheme,
    globalConfig,
    setGlobalConfig,
    geminiApiKey,
    setGeminiApiKey,
    adminSession,
    resetChat,
  } = useApp();

  const [showApiKey, setShowApiKey] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testMessage, setTestMessage] = useState('');

  const handleTestConnection = async () => {
    if (!geminiApiKey) {
      setTestStatus('error');
      setTestMessage('Insira uma API Key primeiro');
      return;
    }

    setTestStatus('testing');
    const result = await testGeminiConnection(geminiApiKey);
    setTestStatus(result.success ? 'success' : 'error');
    setTestMessage(result.message);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="glass-strong w-full sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Configurações</SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Theme Toggle */}
          <div className="flex items-center justify-between">
            <Label>Tema escuro</Label>
            <Switch
              checked={theme === 'dark'}
              onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
            />
          </div>

          {/* Gemini API Key - Only show if admin */}
          {adminSession.isAuthenticated && (
            <div className="space-y-3 pt-4 border-t">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-warning" />
                <span className="text-xs text-muted-foreground">
                  Proteja sua API Key. Em produção, use um backend/proxy.
                </span>
              </div>

              <div className="space-y-2">
                <Label>Gemini API Key</Label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Input
                      type={showApiKey ? 'text' : 'password'}
                      value={geminiApiKey}
                      onChange={(e) => setGeminiApiKey(e.target.value)}
                      placeholder="Sua API Key do Gemini"
                      className="bg-secondary/50 pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full"
                      onClick={() => setShowApiKey(!showApiKey)}
                    >
                      {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={handleTestConnection}
                disabled={testStatus === 'testing'}
              >
                {testStatus === 'testing' && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                {testStatus === 'success' && <Check className="h-4 w-4 mr-2 text-success" />}
                {testStatus === 'error' && <X className="h-4 w-4 mr-2 text-destructive" />}
                Testar conexão
              </Button>

              {testMessage && (
                <p className={`text-xs ${testStatus === 'success' ? 'text-success' : 'text-destructive'}`}>
                  {testMessage}
                </p>
              )}

              <div className="space-y-2">
                <Label>Modelo Gemini</Label>
                <Select
                  value={globalConfig.geminiModel}
                  onValueChange={(value) => setGlobalConfig({ ...globalConfig, geminiModel: value })}
                >
                  <SelectTrigger className="bg-secondary/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gemini-1.5-flash">Gemini 1.5 Flash (rápido)</SelectItem>
                    <SelectItem value="gemini-1.5-pro">Gemini 1.5 Pro (avançado)</SelectItem>
                    <SelectItem value="gemini-1.0-pro">Gemini 1.0 Pro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Temperatura: {globalConfig.temperature}</Label>
                <Slider
                  value={[globalConfig.temperature]}
                  onValueChange={([value]) => setGlobalConfig({ ...globalConfig, temperature: value })}
                  min={0}
                  max={1}
                  step={0.1}
                />
              </div>

              <div className="space-y-2">
                <Label>Top P: {globalConfig.topP}</Label>
                <Slider
                  value={[globalConfig.topP]}
                  onValueChange={([value]) => setGlobalConfig({ ...globalConfig, topP: value })}
                  min={0}
                  max={1}
                  step={0.05}
                />
              </div>

              <div className="space-y-2">
                <Label>Max Output Tokens: {globalConfig.maxOutputTokens}</Label>
                <Slider
                  value={[globalConfig.maxOutputTokens]}
                  onValueChange={([value]) => setGlobalConfig({ ...globalConfig, maxOutputTokens: value })}
                  min={256}
                  max={4096}
                  step={256}
                />
              </div>
            </div>
          )}

          {/* Reset Chat */}
          <div className="pt-4 border-t">
            <Button variant="outline" onClick={resetChat} className="w-full">
              Reiniciar conversa
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
