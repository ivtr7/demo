import { useState, useRef, useEffect, useCallback } from 'react';
import { useApp } from '@/contexts/AppContext';
import { generateAgentReply, fillTemplate } from '@/services/llm';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Settings, Send, Download, AlertCircle, Sparkles, Cpu } from 'lucide-react';
import { ICON_MAP } from '@/data/niches';
import ChatBubble from './ChatBubble';
import TypingIndicator from './TypingIndicator';
import { toast } from 'sonner';

interface ChatInterfaceProps {
  onBack: () => void;
  onOpenSettings: () => void;
}

// Patterns to detect when user is asking about the agent's name
const ASKING_AGENT_NAME_PATTERNS = [
  /qual\s+(?:é\s+)?(?:o\s+)?seu\s+nome/i,
  /como\s+(?:você\s+)?se\s+chama/i,
  /quem\s+é\s+você/i,
  /seu\s+nome/i,
  /você\s+é\s+quem/i,
];

function isAskingAgentName(message: string): boolean {
  return ASKING_AGENT_NAME_PATTERNS.some(pattern => pattern.test(message));
}

export default function ChatInterface({ onBack, onOpenSettings }: ChatInterfaceProps) {
  const {
    currentNiche,
    chatState,
    setChatState,
    addMessage,
    globalConfig,
    geminiApiKey,
    hasApiKey,
  } = useApp();

  const [input, setInput] = useState('');
  const [aiSource, setAiSource] = useState<'gemini' | 'lovable-ai' | 'error' | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Use ref to always have the latest chatState in async callbacks
  const chatStateRef = useRef(chatState);
  useEffect(() => {
    chatStateRef.current = chatState;
  }, [chatState]);

  const Icon = currentNiche ? ICON_MAP[currentNiche.icon] : null;

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatState.messages, chatState.isTyping]);

  // Send greeting on mount - only once
  const greetingSent = useRef(false);
  useEffect(() => {
    if (currentNiche && chatState.messages.length === 0 && chatState.onboarding.step === 'greeting' && !greetingSent.current) {
      greetingSent.current = true;
      
      const greeting = fillTemplate(currentNiche.onboarding.greeting, {
        userName: '',
        businessName: '',
        extraValue: '',
        niche: currentNiche,
      });
      
      setChatState(prev => ({ ...prev, isTyping: true }));
      
      setTimeout(() => {
        addMessage({ role: 'assistant', content: greeting });
        setChatState(prev => ({
          ...prev,
          isTyping: false,
          onboarding: { ...prev.onboarding, step: 'name' },
        }));
      }, 1000);
    }
  }, [currentNiche?.id]);

  // Reset greeting flag when niche changes
  useEffect(() => {
    greetingSent.current = false;
  }, [currentNiche?.id]);

  const processOnboardingStep = useCallback((
    currentStep: string,
    userMessage: string,
    currentOnboarding: typeof chatState.onboarding
  ): { response: string; nextStep: string; updatedData: Partial<typeof chatState.onboarding> } | null => {
    if (!currentNiche) return null;

    const context = {
      userName: currentOnboarding.userName,
      businessName: currentOnboarding.businessName,
      extraValue: currentOnboarding.extraValue,
      niche: currentNiche,
    };

    switch (currentStep) {
      case 'name': {
        // Check if user is asking about agent's name instead of providing their own
        if (isAskingAgentName(userMessage)) {
          return {
            response: `Eu sou ${currentNiche.agentName}! 😊 E você, qual é o seu nome?`,
            nextStep: 'name', // Stay on same step
            updatedData: {},
          };
        }
        
        // User provided their name
        const userName = userMessage.trim();
        const businessQuestion = fillTemplate(currentNiche.onboarding.askBusiness, {
          ...context,
          userName,
        });
        
        return {
          response: businessQuestion,
          nextStep: 'business',
          updatedData: { userName },
        };
      }

      case 'business': {
        const businessName = userMessage.trim();
        const extraQuestion = fillTemplate(currentNiche.onboarding.askExtra, {
          ...context,
          businessName,
        });
        
        return {
          response: extraQuestion,
          nextStep: 'extra',
          updatedData: { businessName },
        };
      }

      case 'extra': {
        const extraValue = userMessage.trim();
        const completionMessage = `Perfeito, ${currentOnboarding.userName}! Agora que conheço um pouco sobre você e a ${currentOnboarding.businessName}, como posso ajudá-lo(a) hoje? Estou aqui para auxiliar com ${extraValue}.`;
        
        return {
          response: completionMessage,
          nextStep: 'complete',
          updatedData: { extraValue },
        };
      }

      default:
        return null;
    }
  }, [currentNiche]);

  const handleSend = async () => {
    if (!input.trim() || !currentNiche || chatState.isTyping) return;

    const userMessage = input.trim();
    setInput('');
    addMessage({ role: 'user', content: userMessage });
    setChatState(prev => ({ ...prev, isTyping: true }));

    // Delay for typing effect
    const typingDelay = 900 + Math.random() * 500;

    setTimeout(async () => {
      // Get the LATEST state via ref
      const currentState = chatStateRef.current;
      const { onboarding, messages } = currentState;
      
      let response = '';
      let source: 'gemini' | 'lovable-ai' | 'error' | null = null;

      // Handle onboarding steps
      if (onboarding.step !== 'complete') {
        const result = processOnboardingStep(onboarding.step, userMessage, onboarding);
        
        if (result) {
          response = result.response;
          
          // Update onboarding state
          setChatState(prev => ({
            ...prev,
            onboarding: {
              ...prev.onboarding,
              ...result.updatedData,
              step: result.nextStep as typeof prev.onboarding.step,
            },
          }));
        } else {
          response = 'Desculpe, algo deu errado. Pode repetir?';
        }
      } else {
        // Regular chat - use AI
        try {
          const result = await generateAgentReply(
            userMessage,
            messages.map(m => ({ role: m.role, content: m.content })),
            {
              userName: onboarding.userName,
              businessName: onboarding.businessName,
              extraValue: onboarding.extraValue,
              niche: currentNiche,
            },
            {
              apiKey: geminiApiKey,
              model: globalConfig.geminiModel,
              temperature: globalConfig.temperature,
              topP: globalConfig.topP,
              maxOutputTokens: globalConfig.maxOutputTokens,
            }
          );
          
          response = result.response;
          source = result.source;
          setAiSource(source);
          
          if (source === 'error') {
            toast.error('Erro ao processar mensagem');
          }
        } catch (error) {
          console.error('AI error:', error);
          response = 'Desculpe, estou com dificuldades técnicas. Tente novamente.';
          source = 'error';
          setAiSource(source);
        }
      }

      addMessage({ role: 'assistant', content: response });
      setChatState(prev => ({ ...prev, isTyping: false }));
    }, typingDelay);
  };

  const handleQuickReply = (message: string) => {
    setInput(message);
    setTimeout(() => inputRef.current?.focus(), 0);
  };

  const handleExport = () => {
    const { onboarding, messages } = chatState;
    let content = `=== Exportação de Conversa ===\n`;
    content += `Nicho: ${currentNiche?.name}\n`;
    content += `Agente: ${currentNiche?.agentName}\n`;
    content += `\n=== Dados Coletados ===\n`;
    content += `Nome: ${onboarding.userName}\n`;
    content += `Empresa: ${onboarding.businessName}\n`;
    content += `${currentNiche?.onboarding.extraFieldName}: ${onboarding.extraValue}\n`;
    content += `\n=== Histórico ===\n\n`;
    
    messages.forEach(msg => {
      const time = new Date(msg.timestamp).toLocaleTimeString('pt-BR');
      const role = msg.role === 'user' ? 'Você' : currentNiche?.agentName;
      content += `[${time}] ${role}:\n${msg.content}\n\n`;
    });

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `conversa-${currentNiche?.id}-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!currentNiche) return null;

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] animate-fade-in">
      {/* Chat Header */}
      <div className="glass-strong border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            
            {Icon && (
              <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center">
                <Icon className="h-5 w-5 text-primary-foreground" />
              </div>
            )}
            
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-semibold">{currentNiche.agentName}</h2>
                <Badge variant="outline" className="text-xs">Demo</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{currentNiche.name}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={handleExport}>
              <Download className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={onOpenSettings}>
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4 max-w-3xl mx-auto">
          {chatState.messages.map((message, index) => (
            <ChatBubble
              key={message.id}
              message={message}
              agentName={currentNiche.agentName}
              index={index}
            />
          ))}
          
          {chatState.isTyping && <TypingIndicator agentName={currentNiche.agentName} />}
        </div>
      </ScrollArea>

      {/* Quick Replies */}
      {chatState.onboarding.step === 'complete' && !chatState.isTyping && (
        <div className="px-4 pb-2">
          <div className="max-w-3xl mx-auto">
            <ScrollArea className="w-full whitespace-nowrap">
              <div className="flex gap-2 pb-2">
                {currentNiche.quickReplies.map(qr => (
                  <Button
                    key={qr.id}
                    variant="outline"
                    size="sm"
                    className="shrink-0 rounded-full"
                    onClick={() => handleQuickReply(qr.message)}
                  >
                    {qr.label}
                  </Button>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>
      )}

      {/* Input */}
      <div className="glass-strong border-t p-4">
        <div className="max-w-3xl mx-auto space-y-2">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex gap-2"
          >
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Digite sua mensagem..."
              className="bg-secondary/50"
              disabled={chatState.isTyping}
            />
            <Button 
              type="submit" 
              className="gradient-primary shrink-0"
              disabled={!input.trim() || chatState.isTyping}
            >
              <Send className="h-5 w-5" />
            </Button>
          </form>

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <AlertCircle className="h-3 w-3" />
              <span>{globalConfig.demoWarning}</span>
            </div>
            {aiSource && chatState.onboarding.step === 'complete' && (
              <Badge variant="secondary" className="text-xs flex items-center gap-1">
                {aiSource === 'gemini' ? (
                  <>
                    <Cpu className="h-3 w-3" />
                    Gemini
                  </>
                ) : aiSource === 'lovable-ai' ? (
                  <>
                    <Sparkles className="h-3 w-3" />
                    Lovable AI
                  </>
                ) : (
                  'Erro'
                )}
              </Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
